<?php



$server ='localhost';
$user ='root';
$password ='';
$database='cs_dept';

$port=3307;

$conn = mysqli_connect($server,$user,$password,$database,$port);
 
 

 ?>