<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Print YMIT form</title>

	 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>

    <style>
    	body{
    		 
    		font-family: century gothic;
    		margin:20px;
    	}
    	.heading{
    		text-align: center;
    	}
    	h2{
    		font-weight: bold;
    	}
    </style>
</head>
<body>
	
  <div class="heading"> 
   <p>Yeshwant Mahavidyalay Nanded</p>
   <h5>Department of Computer Science & IT</h5>
   <h2>YMIT Festival</h2>
   <p>The Festival of Youth and Technology</p>
   <hr>
    </div>

    <div class="container">
   
 
    </table>
    	
        <h5>Student Info</h5>
        <hr>	
    	<p>	student ID : ></p>
    	<p> Student Name:  </p>
    	<p> Class :  </p>
    	<p>	Mobile : </p>
    	<p>	Email :  </p>
<hr>	
    	<h5>Presentation info</h5>
    	<hr>	
    	<p> Presentation On:  </p>
    	<p>Topic : </p> 
    	<p>Member :  </p>
   <br>	<br>	<br>	
    	<p><span>*Note:</span> Please Carry this Print out with you for YMIT </p>
    </div>




       
</body>
</html>